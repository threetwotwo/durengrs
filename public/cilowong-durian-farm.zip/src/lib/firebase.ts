import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import {
  getFirestore,
  Firestore,
  doc,
  setDoc,
} from 'firebase/firestore';
import { DurianTree, DurianVariant, ReportPhoto } from '../types';
import rawConfig from '../../firebase-applet-config.json';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: null,
      email: null,
      emailVerified: null,
      isAnonymous: null,
      tenantId: null,
      providerInfo: [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Initialize Firebase App
export const app: FirebaseApp =
  getApps().length > 0 ? getApp() : initializeApp(rawConfig);

// Connect strictly to the standard (default) Firestore database
export const db: Firestore = getFirestore(app);

export const activeProjectId = rawConfig.projectId || 'duren-db';

/**
 * Robustly normalizes photo representations from WhatsApp bot submissions.
 * Automatically wraps raw base64 strings into valid data: URIs and preserves public URLs.
 */
export function normalizePhotos(raw: any): ReportPhoto[] {
  if (!raw) return [];
  const list = Array.isArray(raw) ? raw : [raw];
  const results: ReportPhoto[] = [];

  for (const item of list) {
    if (!item) continue;

    if (typeof item === 'string') {
      const trimmed = item.trim();
      if (!trimmed) continue;
      if (trimmed.startsWith('http://') || trimmed.startsWith('https://') || trimmed.startsWith('data:')) {
        results.push({ url: trimmed, thumb: trimmed });
      } else {
        // Raw base64 string
        const mime = trimmed.startsWith('iVBORw') ? 'image/png' : 'image/jpeg';
        const dataUri = `data:${mime};base64,${trimmed}`;
        results.push({ url: dataUri, thumb: dataUri });
      }
    } else if (typeof item === 'object') {
      const mime = item.mimeType || 'image/jpeg';
      let resolvedThumb = '';
      let resolvedUrl = '';

      // Check base64 in item.base64 or item.thumb
      if (item.base64 && typeof item.base64 === 'string') {
        const b64 = item.base64.trim();
        resolvedThumb = b64.startsWith('data:') ? b64 : `data:${mime};base64,${b64}`;
      } else if (item.thumb && typeof item.thumb === 'string') {
        const th = item.thumb.trim();
        if (th.startsWith('http://') || th.startsWith('https://') || th.startsWith('data:')) {
          resolvedThumb = th;
        } else if (th.length > 50) {
          resolvedThumb = `data:${mime};base64,${th}`;
        }
      }

      // Check direct URL
      const directUrl =
        item.url ||
        item.downloadUrl ||
        item.downloadURL ||
        item.src ||
        item.link ||
        item.path ||
        '';

      if (directUrl && typeof directUrl === 'string') {
        const u = directUrl.trim();
        if (u.startsWith('http://') || u.startsWith('https://') || u.startsWith('data:')) {
          resolvedUrl = u;
        }
      }

      if (!resolvedThumb && resolvedUrl) resolvedThumb = resolvedUrl;
      if (!resolvedUrl && resolvedThumb) resolvedUrl = resolvedThumb;

      if (resolvedThumb || resolvedUrl) {
        results.push({
          url: resolvedUrl || resolvedThumb,
          thumb: resolvedThumb || resolvedUrl,
        });
      }
    }
  }

  return results;
}

// Firestore operations
export async function saveTreeToFirestore(tree: Partial<DurianTree> & { id: string }): Promise<void> {
  const path = `trees/${tree.id}`;
  try {
    const docRef = doc(db, 'trees', tree.id);
    const dataToSave: Record<string, any> = { ...tree };
    delete dataToSave.id;
    await setDoc(docRef, dataToSave, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function saveVariantToFirestore(variant: DurianVariant): Promise<void> {
  const path = `variants/${variant.code}`;
  try {
    const docRef = doc(db, 'variants', variant.code);
    const dataToSave: Record<string, any> = { ...variant };
    delete dataToSave.code;
    await setDoc(docRef, dataToSave, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}
