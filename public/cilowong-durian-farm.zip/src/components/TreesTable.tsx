import React, { useState, useMemo } from 'react';
import { useFarm, formatDateTime, formatDate, normalizeTimestamp } from '../context/FarmContext';
import { ConditionBadge } from './ConditionBadge';
import { DurianTree, TreeCondition } from '../types';
import {
  Search,
  Filter,
  Download,
  ArrowUpDown,
  RotateCcw,
  TreeDeciduous,
  Plus,
  Eye,
  Edit3,
} from 'lucide-react';

interface TreesTableProps {
  onSelectTree: (treeId: string) => void;
  onAddNewTree?: () => void;
}

export const TreesTable: React.FC<TreesTableProps> = ({ onSelectTree, onAddNewTree }) => {
  const {
    trees,
    variants,
    filterBlock,
    setFilterBlock,
    filterCondition,
    setFilterCondition,
  } = useFarm();

  const [searchId, setSearchId] = useState('');
  const [filterVariant, setFilterVariant] = useState('all');

  // Sorting
  const [sortField, setSortField] = useState<keyof DurianTree>('id');
  const [sortAsc, setSortAsc] = useState(true);

  // Distinct blocks & variants for dropdowns
  const availableBlocks = useMemo(() => {
    const set = new Set<string>();
    trees.forEach((t) => {
      if (t.block) set.add(t.block);
    });
    return Array.from(set).sort();
  }, [trees]);

  const variantLookup = useMemo(() => {
    const map = new Map<string, string>();
    variants.forEach((v) => {
      map.set(v.code, v.name);
    });
    return map;
  }, [variants]);

  // Filtering
  const filteredTrees = useMemo(() => {
    return trees.filter((tree) => {
      // Search by ID
      if (searchId.trim()) {
        const query = searchId.trim().toLowerCase();
        if (!tree.id.toLowerCase().includes(query)) {
          return false;
        }
      }

      // Filter by block
      if (filterBlock !== 'all' && tree.block !== filterBlock) {
        return false;
      }

      // Filter by variant
      if (filterVariant !== 'all' && tree.variant !== filterVariant) {
        return false;
      }

      // Filter by condition
      if (filterCondition !== 'all' && tree.condition !== filterCondition) {
        return false;
      }

      return true;
    });
  }, [trees, searchId, filterBlock, filterVariant, filterCondition]);

  // Sorting
  const sortedTrees = useMemo(() => {
    const list = [...filteredTrees];
    list.sort((a, b) => {
      let valA: any = a[sortField];
      let valB: any = b[sortField];

      if (valA === undefined || valA === null) valA = '';
      if (valB === undefined || valB === null) valB = '';

      if (sortField === 'datePlanted' || sortField === 'lastReportAt') {
        const timeA = normalizeTimestamp(valA);
        const timeB = normalizeTimestamp(valB);
        return sortAsc ? timeA - timeB : timeB - timeA;
      }

      if (typeof valA === 'number' && typeof valB === 'number') {
        return sortAsc ? valA - valB : valB - valA;
      }

      const strA = String(valA).toLowerCase();
      const strB = String(valB).toLowerCase();

      // Natural alphanumerical sort for IDs like A1, A2, A10
      return sortAsc
        ? strA.localeCompare(strB, undefined, { numeric: true, sensitivity: 'base' })
        : strB.localeCompare(strA, undefined, { numeric: true, sensitivity: 'base' });
    });
    return list;
  }, [filteredTrees, sortField, sortAsc]);

  const handleSort = (field: keyof DurianTree) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(true);
    }
  };

  const handleResetFilters = () => {
    setSearchId('');
    setFilterBlock('all');
    setFilterVariant('all');
    setFilterCondition('all');
  };

  // CSV Export handler
  const handleExportCSV = () => {
    if (filteredTrees.length === 0) return;

    const headers = [
      'Tree ID',
      'Block',
      'Variant Code',
      'Variant Name',
      'Condition',
      'Condition Notes',
      'Trunk Girth (cm)',
      'Canopy Size',
      'Flowering Branches',
      'Flowering Clusters',
      'Estimated Fruit Count',
      'Date Planted',
      'Supplier',
      'General Notes',
      'Last Reported Date',
    ];

    const escapeCsv = (str: any) => {
      if (str === null || str === undefined) return '""';
      const clean = String(str).replace(/"/g, '""');
      return `"${clean}"`;
    };

    const rows = filteredTrees.map((t) => [
      escapeCsv(t.id),
      escapeCsv(t.block),
      escapeCsv(t.variant),
      escapeCsv(variantLookup.get(t.variant) || t.variant),
      escapeCsv(t.condition),
      escapeCsv(t.conditionNotes || ''),
      escapeCsv(t.trunkSize || ''),
      escapeCsv(t.canopySize || ''),
      escapeCsv(t.floweringBranches || 0),
      escapeCsv(t.floweringClusters || 0),
      escapeCsv(t.estimatedFruitCount || 0),
      escapeCsv(formatDate(t.datePlanted)),
      escapeCsv(t.supplier || ''),
      escapeCsv(t.notes || ''),
      escapeCsv(formatDateTime(t.lastReportAt)),
    ]);

    const csvContent =
      '\uFEFF' +
      [headers.join(','), ...rows.map((row) => row.join(','))].join('\r\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute(
      'download',
      `cilowong_durian_trees_${new Date().toISOString().slice(0, 10)}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <h1 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <TreeDeciduous className="w-5 h-5 text-emerald-600" />
            Trees Inventory
          </h1>
          <p className="text-xs text-slate-500">
            Showing {sortedTrees.length} of {trees.length} total registered trees
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            disabled={filteredTrees.length === 0}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg border border-slate-300 disabled:opacity-50 transition-colors shadow-xs"
            title="Download CSV spreadsheet of current filtered list"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Filter / Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {/* Search by ID */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchId}
              onChange={(e) => setSearchId(e.target.value)}
              placeholder="Search Tree ID (e.g. A1)..."
              className="w-full text-xs pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
          </div>

          {/* Block dropdown */}
          <div>
            <select
              value={filterBlock}
              onChange={(e) => setFilterBlock(e.target.value)}
              className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-none text-slate-700"
            >
              <option value="all">All Blocks</option>
              {availableBlocks.map((b) => (
                <option key={b} value={b}>
                  {b}
                </option>
              ))}
            </select>
          </div>

          {/* Variant dropdown */}
          <div>
            <select
              value={filterVariant}
              onChange={(e) => setFilterVariant(e.target.value)}
              className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-none text-slate-700"
            >
              <option value="all">All Variants</option>
              {variants.map((v) => (
                <option key={v.code} value={v.code}>
                  {v.code} - {v.name}
                </option>
              ))}
            </select>
          </div>

          {/* Condition dropdown */}
          <div>
            <select
              value={filterCondition}
              onChange={(e) => setFilterCondition(e.target.value)}
              className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-none text-slate-700"
            >
              <option value="all">All Conditions</option>
              <option value="healthy">Healthy (Green)</option>
              <option value="minor">Minor Issue (Orange)</option>
              <option value="emergency">Emergency Action (Red)</option>
            </select>
          </div>

          {/* Reset Filters */}
          <div className="flex items-center">
            <button
              onClick={handleResetFilters}
              className="w-full flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors border border-slate-200"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Filters</span>
            </button>
          </div>
        </div>

        {/* Active filter summary pill indicators */}
        {(filterBlock !== 'all' ||
          filterVariant !== 'all' ||
          filterCondition !== 'all' ||
          searchId.trim() !== '') && (
          <div className="flex items-center gap-2 pt-2 border-t border-slate-100 text-xs text-slate-500">
            <span>Active filters:</span>
            {searchId.trim() && (
              <span className="font-semibold text-slate-800">
                ID contains &ldquo;{searchId}&rdquo;
              </span>
            )}
            {filterBlock !== 'all' && (
              <>
                <span aria-hidden="true">·</span>
                <span className="font-semibold text-slate-800">{filterBlock}</span>
              </>
            )}
            {filterVariant !== 'all' && (
              <>
                <span aria-hidden="true">·</span>
                <span className="font-semibold text-slate-800">
                  {variantLookup.get(filterVariant) || filterVariant}
                </span>
              </>
            )}
            {filterCondition !== 'all' && (
              <>
                <span aria-hidden="true">·</span>
                <span className="font-semibold text-slate-800 capitalize">
                  {filterCondition}
                </span>
              </>
            )}
          </div>
        )}
      </div>

      {/* Main Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead className="bg-slate-100 text-slate-700 font-semibold uppercase text-[10px] tracking-wider border-b border-slate-200">
              <tr>
                <th
                  onClick={() => handleSort('id')}
                  className="py-3 px-3.5 cursor-pointer hover:bg-slate-200/70 transition-colors"
                >
                  <div className="flex items-center gap-1">
                    <span>Tree ID</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('block')}
                  className="py-3 px-3 cursor-pointer hover:bg-slate-200/70 transition-colors"
                >
                  <div className="flex items-center gap-1">
                    <span>Block</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('variant')}
                  className="py-3 px-3 cursor-pointer hover:bg-slate-200/70 transition-colors"
                >
                  <div className="flex items-center gap-1">
                    <span>Variant</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('condition')}
                  className="py-3 px-3 cursor-pointer hover:bg-slate-200/70 transition-colors"
                >
                  <div className="flex items-center gap-1">
                    <span>Health Condition</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('trunkSize')}
                  className="py-3 px-3 text-right cursor-pointer hover:bg-slate-200/70 transition-colors"
                >
                  <div className="flex items-center justify-end gap-1">
                    <span>Trunk Girth</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('canopySize')}
                  className="py-3 px-3 text-right cursor-pointer hover:bg-slate-200/70 transition-colors hidden md:table-cell"
                >
                  <div className="flex items-center justify-end gap-1">
                    <span>Canopy</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('floweringClusters')}
                  className="py-3 px-3 text-right cursor-pointer hover:bg-slate-200/70 transition-colors hidden lg:table-cell"
                >
                  <div className="flex items-center justify-end gap-1">
                    <span>Clusters</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('estimatedFruitCount')}
                  className="py-3 px-3 text-right cursor-pointer hover:bg-slate-200/70 transition-colors"
                >
                  <div className="flex items-center justify-end gap-1">
                    <span>Est. Fruits</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('datePlanted')}
                  className="py-3 px-3 cursor-pointer hover:bg-slate-200/70 transition-colors whitespace-nowrap"
                >
                  <div className="flex items-center gap-1">
                    <span>Date Planted</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('supplier')}
                  className="py-3 px-3 cursor-pointer hover:bg-slate-200/70 transition-colors whitespace-nowrap"
                >
                  <div className="flex items-center gap-1">
                    <span>Supplier</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('notes')}
                  className="py-3 px-3 cursor-pointer hover:bg-slate-200/70 transition-colors whitespace-nowrap"
                >
                  <div className="flex items-center gap-1">
                    <span>Notes</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('lastReportAt')}
                  className="py-3 px-3 cursor-pointer hover:bg-slate-200/70 transition-colors hidden sm:table-cell"
                >
                  <div className="flex items-center gap-1">
                    <span>Last Inspection</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th className="py-3 px-3 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {sortedTrees.length === 0 ? (
                <tr>
                  <td colSpan={13} className="py-12 text-center text-slate-400">
                    <p className="text-sm font-medium">No trees match your current filter criteria.</p>
                    <button
                      onClick={handleResetFilters}
                      className="mt-2 text-xs text-emerald-600 hover:text-emerald-700 font-semibold underline"
                    >
                      Clear all filters
                    </button>
                  </td>
                </tr>
              ) : (
                sortedTrees.map((tree) => {
                  const variantName = variantLookup.get(tree.variant) || tree.variant;
                  return (
                    <tr
                      key={tree.id}
                      onClick={() => onSelectTree(tree.id)}
                      className="hover:bg-slate-50 transition-colors cursor-pointer group"
                    >
                      {/* ID */}
                      <td className="py-2.5 px-3.5 font-mono font-bold text-slate-900 group-hover:text-emerald-700 whitespace-nowrap">
                        <span className="bg-slate-100 group-hover:bg-emerald-100 text-slate-900 group-hover:text-emerald-900 px-2 py-0.5 rounded border border-slate-300 group-hover:border-emerald-300">
                          {tree.id}
                        </span>
                      </td>

                      {/* Block */}
                      <td className="py-2.5 px-3 text-slate-700 font-medium whitespace-nowrap">
                        {tree.block || '—'}
                      </td>

                      {/* Variant */}
                      <td className="py-2.5 px-3 whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono font-semibold text-slate-800 bg-slate-100 px-1.5 py-0.5 rounded text-[11px]">
                            {tree.variant}
                          </span>
                          <span className="text-slate-600 text-xs truncate max-w-[150px]">
                            {variantName}
                          </span>
                        </div>
                      </td>

                      {/* Condition Badge (Colour coded green/orange/red) */}
                      <td className="py-2.5 px-3 whitespace-nowrap">
                        <ConditionBadge condition={tree.condition} size="sm" />
                      </td>

                      {/* Trunk girth */}
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-800">
                        {tree.trunkSize ? `${tree.trunkSize} cm` : '—'}
                      </td>

                      {/* Canopy size */}
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-600 hidden md:table-cell">
                        {tree.canopySize || '—'}
                      </td>

                      {/* Flowering clusters */}
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-600 hidden lg:table-cell">
                        {tree.floweringClusters !== undefined ? tree.floweringClusters : '—'}
                      </td>

                      {/* Estimated fruit count */}
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums font-semibold text-emerald-800">
                        {tree.estimatedFruitCount !== undefined ? tree.estimatedFruitCount : '—'}
                      </td>

                      {/* Date Planted */}
                      <td className="py-2.5 px-3 font-mono text-slate-600 whitespace-nowrap">
                        {formatDate(tree.datePlanted)}
                      </td>

                      {/* Supplier */}
                      <td className="py-2.5 px-3 text-slate-700 font-medium whitespace-nowrap">
                        {tree.supplier || '—'}
                      </td>

                      {/* Notes */}
                      <td className="py-2.5 px-3 text-slate-600 max-w-[200px] truncate" title={tree.notes || ''}>
                        {tree.notes ? (
                          <span className="truncate block">{tree.notes}</span>
                        ) : (
                          <span className="text-slate-300">—</span>
                        )}
                      </td>

                      {/* Last reported */}
                      <td className="py-2.5 px-3 text-slate-500 whitespace-nowrap hidden sm:table-cell">
                        {formatDateTime(tree.lastReportAt)}
                      </td>

                      {/* Actions */}
                      <td
                        className="py-2.5 px-3 text-center whitespace-nowrap"
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectTree(tree.id);
                        }}
                      >
                        <button
                          className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-600 hover:text-white rounded border border-emerald-300 transition-colors"
                          title="View and edit tree details"
                        >
                          <Edit3 className="w-3 h-3" />
                          <span>Edit</span>
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
