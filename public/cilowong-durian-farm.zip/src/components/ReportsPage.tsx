import React, { useState, useMemo } from 'react';
import { useFarm, formatDateTime } from '../context/FarmContext';
import { ConditionBadge } from './ConditionBadge';
import { PhotoLightbox } from './PhotoLightbox';
import { ReportPhoto } from '../types';
import {
  ClipboardList,
  Search,
  User,
  Calendar,
  Image as ImageIcon,
  ArrowRight,
  ExternalLink,
} from 'lucide-react';

const ReportThumbnail: React.FC<{
  photo: ReportPhoto;
  idx: number;
  reportDate: any;
  treeId: string;
  onOpen: (url: string, caption: string) => void;
}> = ({ photo, idx, reportDate, treeId, onOpen }) => {
  const [loadFailed, setLoadFailed] = useState(false);
  const src = photo.thumb || photo.url;
  const caption = `Tree ${treeId} · Photo ${idx + 1} (${formatDateTime(reportDate)})`;

  return (
    <div
      onClick={() => onOpen(photo.url, caption)}
      className="relative w-20 h-20 rounded-lg overflow-hidden border border-slate-200 bg-slate-100 cursor-pointer group hover:ring-2 hover:ring-emerald-500 transition-all shadow-xs flex items-center justify-center"
    >
      {!loadFailed ? (
        <img
          src={src}
          alt={`Photo ${idx + 1}`}
          loading="lazy"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
          onError={() => setLoadFailed(true)}
        />
      ) : (
        <div className="w-full h-full flex flex-col items-center justify-center p-1 text-center text-slate-500 bg-slate-50">
          <ImageIcon className="w-4 h-4 mb-0.5 text-slate-400" />
          <span className="text-[9px] font-semibold">Photo {idx + 1}</span>
        </div>
      )}

      <div className="absolute inset-0 bg-slate-950/30 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity text-white">
        <ExternalLink className="w-3.5 h-3.5" />
      </div>
    </div>
  );
};

export const ReportsPage: React.FC = () => {
  const { reports, trees, variants, setSelectedTreeId, setActiveTab } = useFarm();

  const [search, setSearch] = useState('');
  const [filterBlock, setFilterBlock] = useState('all');
  const [onlyChanged, setOnlyChanged] = useState(false);
  const [activePhoto, setActivePhoto] = useState<{ url: string; caption?: string } | null>(null);

  // Available blocks
  const availableBlocks = useMemo(() => {
    const set = new Set<string>();
    reports.forEach((r) => {
      if (r.block) set.add(r.block);
    });
    return Array.from(set).sort();
  }, [reports]);

  // Filtered reports, newest first
  const filteredReports = useMemo(() => {
    return reports.filter((rep) => {
      if (search.trim()) {
        const q = search.trim().toLowerCase();
        const matchesTree = rep.treeId.toLowerCase().includes(q);
        const matchesPhone = rep.workerPhone && rep.workerPhone.toLowerCase().includes(q);
        const matchesDesc = rep.description && rep.description.toLowerCase().includes(q);
        if (!matchesTree && !matchesPhone && !matchesDesc) return false;
      }

      if (filterBlock !== 'all' && rep.block !== filterBlock) {
        return false;
      }

      if (onlyChanged && !rep.conditionChanged) {
        return false;
      }

      return true;
    });
  }, [reports, search, filterBlock, onlyChanged]);

  const handleInspectTree = (treeId: string) => {
    setSelectedTreeId(treeId);
    setActiveTab('trees');
  };

  return (
    <div className="space-y-4">
      {/* Sleek Header & Controls */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <ClipboardList className="w-5 h-5 text-emerald-600" />
            WhatsApp Inspection Logs
          </h1>
          <p className="text-xs text-slate-500">
            Real-time feed of field submissions from worker WhatsApp chats
          </p>
        </div>

        {/* Filter & Search Bar */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Search */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search tree, phone, note..."
              className="text-xs pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-none w-52"
            />
          </div>

          {/* Block filter */}
          <select
            value={filterBlock}
            onChange={(e) => setFilterBlock(e.target.value)}
            className="text-xs py-1.5 px-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-none"
          >
            <option value="all">All Blocks</option>
            {availableBlocks.map((b) => (
              <option key={b} value={b}>
                Block {b}
              </option>
            ))}
          </select>

          {/* Condition Changed Toggle */}
          <button
            onClick={() => setOnlyChanged(!onlyChanged)}
            className={`text-xs px-3 py-1.5 rounded-lg border font-medium transition-colors ${
              onlyChanged
                ? 'bg-amber-500 text-white border-amber-600'
                : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
            }`}
          >
            Status Changes Only
          </button>
        </div>
      </div>

      {/* Reports List */}
      <div className="space-y-3">
        {filteredReports.length === 0 ? (
          <div className="bg-white rounded-xl p-12 text-center border border-slate-200 shadow-xs">
            <p className="text-sm font-semibold text-slate-700">No inspection reports match your filter</p>
          </div>
        ) : (
          filteredReports.map((report) => {
            const photos = report.photos || [];
            const tree = trees.find((t) => t.id === report.treeId);
            const variantObj = variants.find((v) => v.code === tree?.variant);
            const variantDisplay = variantObj?.name && variantObj.name !== tree?.variant
              ? `${tree?.variant} - ${variantObj.name}`
              : (variantObj?.name || tree?.variant || '—');

            return (
              <div
                key={report.id}
                className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs space-y-3 hover:border-slate-300 transition-colors"
              >
                {/* Header & Subheading */}
                <div className="border-b border-slate-100 pb-2.5 space-y-1">
                  {/* Header row: Tree A12 · MK & Condition */}
                  <div className="flex items-center justify-between gap-2">
                    <button
                      onClick={() => handleInspectTree(report.treeId)}
                      className="text-base font-bold font-mono text-emerald-800 hover:text-emerald-600 hover:underline flex items-center gap-1.5"
                    >
                      <span>Tree {report.treeId} · {tree?.variant || 'MK'}</span>
                      <ArrowRight className="w-4 h-4 opacity-60" />
                    </button>

                    <div>
                      {report.conditionChanged && report.conditionBefore && report.conditionAfter ? (
                        <div className="flex items-center gap-1 text-xs">
                          <span className="text-slate-400 lowercase">{report.conditionBefore}</span>
                          <span className="text-slate-400">→</span>
                          <ConditionBadge condition={report.conditionAfter} size="sm" />
                        </div>
                      ) : (
                        report.conditionAfter && (
                          <ConditionBadge condition={report.conditionAfter} size="sm" />
                        )
                      )}
                    </div>
                  </div>

                  {/* Subheading row: Block name horizontally aligned with report date */}
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <span className="font-medium">Block {report.block || tree?.block || '—'}</span>
                    <span className="text-slate-400 flex items-center gap-1 text-[11px]">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      {formatDateTime(report.createdAt)}
                    </span>
                  </div>
                </div>

                {/* Worker Phone & Description */}
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                  {report.description && (
                    <p className="text-xs text-slate-800 leading-relaxed bg-slate-50 p-2.5 rounded-lg border border-slate-100 flex-1">
                      {report.description}
                    </p>
                  )}

                  {report.workerPhone && (
                    <div className="text-[11px] text-slate-500 flex items-center gap-1.5 font-mono shrink-0">
                      <User className="w-3 h-3 text-slate-400" />
                      <span>{report.workerPhone}</span>
                    </div>
                  )}
                </div>

                {/* Photos */}
                {photos.length > 0 && (
                  <div className="pt-1">
                    <div className="flex flex-wrap gap-2">
                      {photos.map((photo, pIdx) => (
                        <ReportThumbnail
                          key={pIdx}
                          photo={photo}
                          idx={pIdx}
                          reportDate={report.createdAt}
                          treeId={report.treeId}
                          onOpen={(url, caption) => setActivePhoto({ url, caption })}
                        />
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Lightbox */}
      <PhotoLightbox
        photoUrl={activePhoto?.url || null}
        caption={activePhoto?.caption}
        onClose={() => setActivePhoto(null)}
      />
    </div>
  );
};
