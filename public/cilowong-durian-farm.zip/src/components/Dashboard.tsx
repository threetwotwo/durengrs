import React, { useState, useMemo } from 'react';
import { useFarm, formatDateTime } from '../context/FarmContext';
import { ConditionBadge } from './ConditionBadge';
import { PhotoLightbox } from './PhotoLightbox';
import { ReportPhoto, TreeCondition } from '../types';
import {
  ShieldCheck,
  AlertTriangle,
  AlertOctagon,
  TreeDeciduous,
  ArrowRight,
  ArrowUpDown,
  User,
  Calendar,
  Layers,
  Image as ImageIcon,
  ExternalLink,
} from 'lucide-react';

const DashboardReportThumb: React.FC<{
  photo: ReportPhoto;
  idx: number;
  reportDate: any;
  treeId: string;
  onOpen: (url: string, caption: string) => void;
}> = ({ photo, idx, reportDate, treeId, onOpen }) => {
  const [loadFailed, setLoadFailed] = useState(false);
  const src = photo.thumb || photo.url;
  const caption = `Tree ${treeId} · Photo ${idx + 1} (${formatDateTime(reportDate)})`;

  return (
    <div
      onClick={(e) => {
        e.stopPropagation();
        onOpen(photo.url, caption);
      }}
      className="relative w-12 h-12 rounded-md overflow-hidden border border-slate-200 bg-slate-100 cursor-pointer group hover:ring-2 hover:ring-emerald-500 transition-all shadow-2xs shrink-0 flex items-center justify-center"
    >
      {!loadFailed ? (
        <img
          src={src}
          alt={`Photo ${idx + 1}`}
          loading="lazy"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
          onError={() => setLoadFailed(true)}
        />
      ) : (
        <ImageIcon className="w-4 h-4 text-slate-400" />
      )}
      <div className="absolute inset-0 bg-slate-950/20 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity text-white">
        <ExternalLink className="w-3 h-3" />
      </div>
    </div>
  );
};

export const Dashboard: React.FC = () => {
  const {
    trees,
    reports,
    variants,
    totalFruits,
    setActiveTab,
    setSelectedTreeId,
    setFilterBlock,
    setFilterCondition,
  } = useFarm();

  const [blockSortField, setBlockSortField] = useState<'block' | 'healthy' | 'minor' | 'emergency' | 'total'>('total');
  const [blockSortAsc, setBlockSortAsc] = useState(false);
  const [activePhoto, setActivePhoto] = useState<{ url: string; caption?: string } | null>(null);

  // Condition counts
  const counts = useMemo(() => {
    let healthy = 0;
    let minor = 0;
    let emergency = 0;

    trees.forEach((t) => {
      if (t.condition === 'healthy') healthy++;
      else if (t.condition === 'minor') minor++;
      else if (t.condition === 'emergency') emergency++;
    });

    const total = trees.length;
    return {
      healthy,
      minor,
      emergency,
      total,
      healthyPct: total ? Math.round((healthy / total) * 100) : 0,
      minorPct: total ? Math.round((minor / total) * 100) : 0,
      emergencyPct: total ? Math.round((emergency / total) * 100) : 0,
    };
  }, [trees]);

  // Per-block breakdown
  const blockStats = useMemo(() => {
    const map = new Map<
      string,
      { block: string; healthy: number; minor: number; emergency: number; total: number; fruits: number }
    >();

    trees.forEach((t) => {
      const b = t.block || 'Unassigned';
      if (!map.has(b)) {
        map.set(b, { block: b, healthy: 0, minor: 0, emergency: 0, total: 0, fruits: 0 });
      }
      const entry = map.get(b)!;
      entry.total++;
      entry.fruits += t.estimatedFruitCount || 0;
      if (t.condition === 'healthy') entry.healthy++;
      else if (t.condition === 'minor') entry.minor++;
      else if (t.condition === 'emergency') entry.emergency++;
    });

    const list = Array.from(map.values());

    list.sort((a, b) => {
      const valA = a[blockSortField];
      const valB = b[blockSortField];
      if (typeof valA === 'string') {
        return blockSortAsc
          ? valA.localeCompare(valB as string)
          : (valB as string).localeCompare(valA);
      }
      return blockSortAsc ? (valA as number) - (valB as number) : (valB as number) - (valA as number);
    });

    return list;
  }, [trees, blockSortField, blockSortAsc]);

  // Latest 8 reports
  const latestReports = useMemo(() => {
    return reports.slice(0, 8);
  }, [reports]);

  const handleBlockSort = (field: 'block' | 'healthy' | 'minor' | 'emergency' | 'total') => {
    if (blockSortField === field) {
      setBlockSortAsc(!blockSortAsc);
    } else {
      setBlockSortField(field);
      setBlockSortAsc(false);
    }
  };

  const handleNavigateToBlock = (block: string) => {
    setFilterBlock(block);
    setFilterCondition('all');
    setActiveTab('trees');
  };

  const handleFilterByCondition = (condition: TreeCondition) => {
    setFilterCondition(condition);
    setFilterBlock('all');
    setActiveTab('trees');
  };

  const handleInspectTree = (treeId: string) => {
    setSelectedTreeId(treeId);
    setActiveTab('trees');
  };

  return (
    <div className="space-y-5">
      {/* KPI Cards: Executive Status */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* Total Trees & Estimated Yield */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold uppercase tracking-wider">
            <span>Orchard Inventory</span>
            <TreeDeciduous className="w-4 h-4 text-slate-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-bold text-slate-900 font-mono tabular-nums">
              {counts.total}
            </span>
            <span className="text-xs text-slate-500">trees</span>
          </div>
          <div className="mt-2.5 text-[11px] text-slate-600 flex items-center justify-between pt-2 border-t border-slate-100">
            <span>{totalFruits.toLocaleString()} est. fruits</span>
            <button
              onClick={() => setActiveTab('trees')}
              className="text-emerald-700 hover:text-emerald-800 font-semibold"
            >
              View →
            </button>
          </div>
        </div>

        {/* Healthy */}
        <div
          onClick={() => handleFilterByCondition('healthy')}
          className="bg-emerald-50/70 hover:bg-emerald-50 border border-emerald-200 rounded-xl p-4 shadow-xs cursor-pointer transition-all"
        >
          <div className="flex items-center justify-between text-emerald-800 text-xs font-semibold uppercase tracking-wider">
            <span>Healthy</span>
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl sm:text-3xl font-bold text-emerald-900 font-mono tabular-nums">
              {counts.healthy}
            </span>
            <span className="text-xs font-bold text-emerald-700 font-mono">
              {counts.healthyPct}%
            </span>
          </div>
          <div className="mt-2.5 text-[11px] text-emerald-700 flex items-center justify-between pt-2 border-t border-emerald-200/60">
            <span>Normal growth</span>
            <span className="font-semibold underline">Filter →</span>
          </div>
        </div>

        {/* Minor */}
        <div
          onClick={() => handleFilterByCondition('minor')}
          className="bg-amber-50/70 hover:bg-amber-50 border border-amber-200 rounded-xl p-4 shadow-xs cursor-pointer transition-all"
        >
          <div className="flex items-center justify-between text-amber-800 text-xs font-semibold uppercase tracking-wider">
            <span>Minor Issues</span>
            <AlertTriangle className="w-4 h-4 text-amber-600" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl sm:text-3xl font-bold text-amber-900 font-mono tabular-nums">
              {counts.minor}
            </span>
            <span className="text-xs font-bold text-amber-700 font-mono">
              {counts.minorPct}%
            </span>
          </div>
          <div className="mt-2.5 text-[11px] text-amber-700 flex items-center justify-between pt-2 border-t border-amber-200/60">
            <span>Needs attention</span>
            <span className="font-semibold underline">Filter →</span>
          </div>
        </div>

        {/* Emergency */}
        <div
          onClick={() => handleFilterByCondition('emergency')}
          className="bg-rose-50/80 hover:bg-rose-50 border border-rose-300 rounded-xl p-4 shadow-xs cursor-pointer transition-all"
        >
          <div className="flex items-center justify-between text-rose-800 text-xs font-bold uppercase tracking-wider">
            <span>Emergency</span>
            <AlertOctagon className="w-4 h-4 text-rose-600" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl sm:text-3xl font-bold text-rose-900 font-mono tabular-nums">
              {counts.emergency}
            </span>
            <span className="text-xs font-bold text-rose-700 font-mono">
              {counts.emergencyPct}%
            </span>
          </div>
          <div className="mt-2.5 text-[11px] text-rose-700 flex items-center justify-between pt-2 border-t border-rose-200">
            <span>Urgent action</span>
            <span className="font-semibold underline">Filter →</span>
          </div>
        </div>
      </div>

      {/* Main Grid: Block Breakdown (Left 7) & Recent Reports (Right 5) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left Column: Block Breakdown Table (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-xl border border-slate-200 shadow-xs flex flex-col overflow-hidden">
          <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Layers className="w-4 h-4 text-emerald-600" />
              Block Distribution
            </h2>
            <span className="text-xs text-slate-500 font-mono">
              {blockStats.length} Blocks
            </span>
          </div>

          <div className="overflow-x-auto flex-1">
            <table className="w-full text-xs text-left border-collapse">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 font-semibold uppercase text-[10px] tracking-wider">
                <tr>
                  <th
                    onClick={() => handleBlockSort('block')}
                    className="py-2.5 px-3.5 cursor-pointer hover:bg-slate-100 transition-colors"
                  >
                    <div className="flex items-center gap-1">
                      <span>Block</span>
                      <ArrowUpDown className="w-3 h-3 text-slate-400" />
                    </div>
                  </th>
                  <th
                    onClick={() => handleBlockSort('healthy')}
                    className="py-2.5 px-3 text-right cursor-pointer hover:bg-slate-100 transition-colors text-emerald-800"
                  >
                    Healthy
                  </th>
                  <th
                    onClick={() => handleBlockSort('minor')}
                    className="py-2.5 px-3 text-right cursor-pointer hover:bg-slate-100 transition-colors text-amber-800"
                  >
                    Minor
                  </th>
                  <th
                    onClick={() => handleBlockSort('emergency')}
                    className="py-2.5 px-3 text-right cursor-pointer hover:bg-slate-100 transition-colors text-rose-800"
                  >
                    Urgent
                  </th>
                  <th
                    onClick={() => handleBlockSort('total')}
                    className="py-2.5 px-3.5 text-right cursor-pointer hover:bg-slate-100 transition-colors"
                  >
                    Total
                  </th>
                  <th className="py-2.5 px-3.5 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {blockStats.map((row) => (
                  <tr key={row.block} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-2.5 px-3.5 font-bold font-mono text-slate-900">
                      Block {row.block}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono text-emerald-700 font-semibold">
                      {row.healthy}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono text-amber-700 font-semibold">
                      {row.minor}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono text-rose-700 font-bold">
                      {row.emergency}
                    </td>
                    <td className="py-2.5 px-3.5 text-right font-mono text-slate-800 font-bold">
                      {row.total}
                    </td>
                    <td className="py-2.5 px-3.5 text-right">
                      <button
                        onClick={() => handleNavigateToBlock(row.block)}
                        className="text-[11px] font-semibold text-emerald-700 hover:text-emerald-900 transition-colors"
                      >
                        Inspect →
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Column: Latest WhatsApp Reports (5 cols) */}
        <div className="lg:col-span-5 bg-white rounded-xl border border-slate-200 shadow-xs flex flex-col overflow-hidden">
          <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-900">Latest Field Reports</h2>
            <button
              onClick={() => setActiveTab('reports')}
              className="text-xs font-semibold text-emerald-700 hover:text-emerald-800"
            >
              All Reports ({reports.length}) →
            </button>
          </div>

          <div className="p-3.5 overflow-y-auto max-h-[500px] space-y-2.5">
            {latestReports.length === 0 ? (
              <div className="py-10 text-center text-slate-400 text-xs">
                No inspection reports submitted yet.
              </div>
            ) : (
              latestReports.map((report) => {
                const photos = report.photos || [];
                const tree = trees.find((t) => t.id === report.treeId);
                const variantObj = variants.find((v) => v.code === tree?.variant);
                const variantDisplay = variantObj?.name && variantObj.name !== tree?.variant
                  ? `${tree?.variant} - ${variantObj.name}`
                  : (variantObj?.name || tree?.variant || '—');

                return (
                  <div
                    key={report.id}
                    onClick={() => handleInspectTree(report.treeId)}
                    className="p-3 rounded-lg border border-slate-200 bg-slate-50/50 hover:bg-slate-50 hover:border-slate-300 transition-all cursor-pointer space-y-2"
                  >
                    <div className="space-y-1">
                      {/* Header row: Tree A12 · MK & Condition */}
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-bold font-mono text-slate-900">
                          Tree {report.treeId} · {tree?.variant || 'MK'}
                        </span>

                        {report.conditionChanged && report.conditionBefore && report.conditionAfter ? (
                          <div className="flex items-center gap-1.5 text-xs">
                            <span className="text-slate-500 font-medium lowercase">{report.conditionBefore}</span>
                            <span className="text-slate-400">→</span>
                            <ConditionBadge condition={report.conditionAfter} size="sm" />
                          </div>
                        ) : (
                          report.conditionAfter && (
                            <ConditionBadge condition={report.conditionAfter} size="sm" />
                          )
                        )}
                      </div>

                      {/* Subheading row: Block name horizontally aligned with report date */}
                      <div className="flex items-center justify-between text-[11px] text-slate-500">
                        <span>Block {report.block || tree?.block || '—'}</span>
                        <span className="text-slate-400 font-normal">
                          {formatDateTime(report.createdAt)}
                        </span>
                      </div>
                    </div>

                    {report.description && (
                      <p className="text-xs text-slate-700 line-clamp-2 leading-relaxed">
                        {report.description}
                      </p>
                    )}

                    {/* Thumbnails + Worker */}
                    <div className="flex items-center justify-between pt-1">
                      {photos.length > 0 ? (
                        <div className="flex items-center gap-1.5">
                          {photos.slice(0, 3).map((photo, pIdx) => (
                            <DashboardReportThumb
                              key={pIdx}
                              photo={photo}
                              idx={pIdx}
                              reportDate={report.createdAt}
                              treeId={report.treeId}
                              onOpen={(url, caption) => setActivePhoto({ url, caption })}
                            />
                          ))}
                          {photos.length > 3 && (
                            <span className="text-[10px] text-slate-500 font-mono">
                              +{photos.length - 3}
                            </span>
                          )}
                        </div>
                      ) : (
                        <span className="text-[10px] text-slate-400">No photos</span>
                      )}

                      {report.workerPhone && (
                        <span className="text-[10px] font-mono text-slate-400 flex items-center gap-1">
                          <User className="w-3 h-3 text-slate-400" />
                          {report.workerPhone}
                        </span>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* Lightbox */}
      <PhotoLightbox
        photoUrl={activePhoto?.url || null}
        caption={activePhoto?.caption}
        onClose={() => setActivePhoto(null)}
      />
    </div>
  );
};
