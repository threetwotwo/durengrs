import React from 'react';
import { TreeCondition } from '../types';
import { CheckCircle2, AlertTriangle, AlertOctagon } from 'lucide-react';

interface ConditionBadgeProps {
  condition: TreeCondition | string;
  size?: 'sm' | 'md' | 'lg';
  showIcon?: boolean;
  className?: string;
}

export const ConditionBadge: React.FC<ConditionBadgeProps> = ({
  condition,
  size = 'md',
  showIcon = true,
  className = '',
}) => {
  const norm = (condition || '').toLowerCase();

  let colorClasses = 'bg-slate-100 text-slate-800 border-slate-300';
  let label = condition || 'Unknown';
  let Icon = CheckCircle2;

  if (norm === 'healthy') {
    colorClasses = 'bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-700';
    label = 'Healthy';
    Icon = CheckCircle2;
  } else if (norm === 'minor') {
    colorClasses = 'bg-amber-100 text-amber-800 border-amber-300 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-700';
    label = 'Minor Issue';
    Icon = AlertTriangle;
  } else if (norm === 'emergency') {
    colorClasses = 'bg-rose-100 text-rose-800 border-rose-300 dark:bg-rose-950/60 dark:text-rose-300 dark:border-rose-700 font-bold';
    label = 'Emergency';
    Icon = AlertOctagon;
  }

  const sizeClasses = {
    sm: 'text-[11px] px-2 py-0.5 gap-1',
    md: 'text-xs px-2.5 py-1 gap-1.5',
    lg: 'text-sm px-3.5 py-1.5 gap-2',
  }[size];

  const iconSizes = {
    sm: 'w-3 h-3',
    md: 'w-3.5 h-3.5',
    lg: 'w-4 h-4',
  }[size];

  return (
    <span
      className={`inline-flex items-center font-medium rounded-md border shrink-0 ${sizeClasses} ${colorClasses} ${className}`}
    >
      {showIcon && <Icon className={`${iconSizes} shrink-0`} />}
      <span>{label}</span>
    </span>
  );
};
