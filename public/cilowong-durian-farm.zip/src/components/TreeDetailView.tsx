import React, { useState, useEffect } from 'react';
import { useFarm, formatDateTime, formatDate } from '../context/FarmContext';
import { DurianTree, TreeCondition, ReportPhoto } from '../types';
import { ConditionBadge } from './ConditionBadge';
import { PhotoLightbox } from './PhotoLightbox';
import {
  ArrowLeft,
  ChevronLeft,
  ChevronRight,
  Save,
  Check,
  Calendar,
  User,
  Clock,
  Sparkles,
  RefreshCw,
  ImageIcon,
  ExternalLink,
} from 'lucide-react';

interface TreeDetailViewProps {
  treeId: string;
  onBack: () => void;
}

// Resilient thumbnail component
const ThumbnailItem: React.FC<{
  photo: ReportPhoto;
  idx: number;
  reportDate: any;
  treeId: string;
  onOpen: (url: string, caption: string) => void;
}> = ({ photo, idx, reportDate, treeId, onOpen }) => {
  const [loadFailed, setLoadFailed] = useState(false);
  const src = photo.thumb || photo.url;
  const caption = `Tree ${treeId} · Photo ${idx + 1} (${formatDateTime(reportDate)})`;

  return (
    <div
      onClick={() => onOpen(photo.url, caption)}
      className="relative aspect-square rounded-lg overflow-hidden border border-slate-200 bg-slate-100 cursor-pointer group hover:ring-2 hover:ring-emerald-500 transition-all shadow-xs flex items-center justify-center"
    >
      {!loadFailed ? (
        <img
          src={src}
          alt={`Photo ${idx + 1}`}
          loading="lazy"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
          onError={() => setLoadFailed(true)}
        />
      ) : (
        <div className="w-full h-full flex flex-col items-center justify-center p-2 text-center text-slate-500 hover:text-emerald-700 bg-slate-50">
          <ImageIcon className="w-5 h-5 mb-1 text-slate-400" />
          <span className="text-[10px] font-semibold">View {idx + 1}</span>
        </div>
      )}

      {/* Hover overlay */}
      <div className="absolute inset-0 bg-slate-950/30 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity text-white">
        <ExternalLink className="w-4 h-4 drop-shadow-sm" />
      </div>
    </div>
  );
};

export const TreeDetailView: React.FC<TreeDetailViewProps> = ({ treeId, onBack }) => {
  const { trees, variants, reports, updateTree, setSelectedTreeId } = useFarm();

  const tree = trees.find((t) => t.id === treeId);
  const treeReports = reports.filter((r) => r.treeId === treeId);

  // Stepper: Previous / Next tree in current inventory
  const currentIndex = trees.findIndex((t) => t.id === treeId);
  const prevTree = currentIndex > 0 ? trees[currentIndex - 1] : null;
  const nextTree = currentIndex < trees.length - 1 ? trees[currentIndex + 1] : null;

  // Local state for editable fields
  const [formData, setFormData] = useState<Partial<DurianTree>>({
    variant: '',
    block: '',
    condition: 'healthy',
    conditionNotes: '',
    canopySize: '',
    trunkSize: 0,
    floweringBranches: 0,
    floweringClusters: 0,
    estimatedFruitCount: 0,
    notes: '',
    supplier: '',
    datePlanted: null,
  });

  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  // Lightbox
  const [activePhoto, setActivePhoto] = useState<{ url: string; caption: string } | null>(null);

  useEffect(() => {
    if (tree) {
      setFormData({
        variant: tree.variant || '',
        block: tree.block || '',
        condition: tree.condition || 'healthy',
        conditionNotes: tree.conditionNotes || '',
        canopySize: tree.canopySize ?? '',
        trunkSize: tree.trunkSize ?? 0,
        floweringBranches: tree.floweringBranches ?? 0,
        floweringClusters: tree.floweringClusters ?? 0,
        estimatedFruitCount: tree.estimatedFruitCount ?? 0,
        notes: tree.notes || '',
        supplier: tree.supplier || '',
        datePlanted: tree.datePlanted,
        lastReportAt: tree.lastReportAt,
      });
    }
  }, [tree, treeId]);

  if (!tree && trees.length > 0) {
    return (
      <div className="bg-white rounded-xl p-8 text-center border border-slate-200 shadow-xs">
        <p className="text-sm font-semibold text-slate-700">Tree {treeId} not found</p>
        <button
          onClick={onBack}
          className="mt-3 px-4 py-1.5 text-xs font-semibold bg-slate-900 text-white rounded-lg hover:bg-slate-800"
        >
          Return to Inventory
        </button>
      </div>
    );
  }

  const handleSave = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsSaving(true);
    setSaveError(null);

    try {
      await updateTree({
        id: treeId,
        variant: formData.variant || '',
        block: formData.block || '',
        condition: formData.condition || 'healthy',
        conditionNotes: formData.conditionNotes || '',
        canopySize: formData.canopySize || '',
        trunkSize: Number(formData.trunkSize) || 0,
        floweringBranches: Number(formData.floweringBranches) || 0,
        floweringClusters: Number(formData.floweringClusters) || 0,
        estimatedFruitCount: Number(formData.estimatedFruitCount) || 0,
        notes: formData.notes || '',
        supplier: formData.supplier || '',
        lastReportAt: formData.lastReportAt,
      });

      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 2500);
    } catch (err: any) {
      setSaveError(`Save failed: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  const conditions: { id: TreeCondition; label: string }[] = [
    { id: 'healthy', label: 'Healthy' },
    { id: 'minor', label: 'Minor Issue' },
    { id: 'emergency', label: 'Emergency' },
  ];

  const currentVariant = variants.find((v) => v.code === formData.variant);

  return (
    <div className="space-y-5">
      {/* Top Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white px-5 py-3.5 rounded-xl border border-slate-200 shadow-xs">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-1.5 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors"
            title="Back to trees"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div>
            <div className="flex items-center gap-2.5">
              <h1 className="text-xl font-bold font-mono tracking-tight text-slate-900">
                Tree {treeId} · {tree?.variant || formData.variant || 'MK'}
              </h1>
              <ConditionBadge condition={formData.condition || 'healthy'} size="md" />
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Block {formData.block || '—'}{currentVariant ? ` · ${currentVariant.name}` : ''}
            </p>
          </div>
        </div>

        {/* Stepper + Save */}
        <div className="flex items-center gap-2">
          {/* Previous / Next */}
          <div className="flex items-center border border-slate-200 rounded-lg overflow-hidden bg-slate-50">
            <button
              onClick={() => prevTree && setSelectedTreeId(prevTree.id)}
              disabled={!prevTree}
              className="p-2 hover:bg-white text-slate-600 hover:text-slate-900 disabled:opacity-30 disabled:hover:bg-transparent transition-colors"
              title={prevTree ? `Previous: ${prevTree.id}` : 'No previous tree'}
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-[11px] font-mono px-2 text-slate-500">
              {currentIndex + 1} / {trees.length}
            </span>
            <button
              onClick={() => nextTree && setSelectedTreeId(nextTree.id)}
              disabled={!nextTree}
              className="p-2 hover:bg-white text-slate-600 hover:text-slate-900 disabled:opacity-30 disabled:hover:bg-transparent transition-colors"
              title={nextTree ? `Next: ${nextTree.id}` : 'No next tree'}
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {saveSuccess && (
            <span className="text-xs text-emerald-600 font-semibold flex items-center gap-1">
              <Check className="w-3.5 h-3.5" /> Saved
            </span>
          )}

          <button
            type="button"
            onClick={handleSave}
            disabled={isSaving}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg shadow-xs disabled:opacity-50 transition-colors"
          >
            {isSaving ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
            <span>Save</span>
          </button>
        </div>
      </div>

      {saveError && (
        <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-lg">
          {saveError}
        </div>
      )}

      {/* Two-Column Layout: Form (Left 7) & Timeline (Right 5) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left: Tree Settings Form */}
        <div className="lg:col-span-7 bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-900">Tree Profile & Metrics</h2>
            {formData.lastReportAt && (
              <span className="text-[11px] text-slate-500 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                Updated {formatDateTime(formData.lastReportAt)}
              </span>
            )}
          </div>

          <form onSubmit={handleSave} className="p-5 space-y-4">
            {/* Condition selector */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-2">
                Tree Health Status
              </label>
              <div className="grid grid-cols-3 gap-2">
                {conditions.map(({ id, label }) => {
                  const isSelected = formData.condition === id;
                  return (
                    <button
                      key={id}
                      type="button"
                      onClick={() => setFormData({ ...formData, condition: id })}
                      className={`py-2 px-3 rounded-lg text-xs font-semibold border transition-all text-center ${
                        isSelected
                          ? id === 'healthy'
                            ? 'bg-emerald-50 border-emerald-500 text-emerald-800 ring-2 ring-emerald-500/20'
                            : id === 'minor'
                            ? 'bg-amber-50 border-amber-500 text-amber-800 ring-2 ring-amber-500/20'
                            : 'bg-rose-50 border-rose-500 text-rose-800 ring-2 ring-rose-500/20'
                          : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      {label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Condition Notes */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Condition Notes & Symptoms
              </label>
              <input
                type="text"
                value={formData.conditionNotes || ''}
                onChange={(e) => setFormData({ ...formData, conditionNotes: e.target.value })}
                placeholder="e.g. Stem borer holes, yellow leaves, fungal spots..."
                className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            {/* Block & Variant */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Block
                </label>
                <input
                  type="text"
                  value={formData.block || ''}
                  onChange={(e) => setFormData({ ...formData, block: e.target.value })}
                  placeholder="A"
                  className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg font-mono focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Variant
                </label>
                <select
                  value={formData.variant || ''}
                  onChange={(e) => setFormData({ ...formData, variant: e.target.value })}
                  className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                >
                  <option value="">Select Variant...</option>
                  {variants.map((v) => (
                    <option key={v.code} value={v.code}>
                      {v.code} - {v.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Supplier & Planting Date */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Supplier
                </label>
                <input
                  type="text"
                  value={formData.supplier || ''}
                  onChange={(e) => setFormData({ ...formData, supplier: e.target.value })}
                  placeholder="e.g. Aziz"
                  className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Date Planted
                </label>
                <div className="text-xs p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono text-slate-700 flex items-center justify-between">
                  <span>{formatDate(formData.datePlanted)}</span>
                  <span className="text-[10px] text-slate-400">Recorded</span>
                </div>
              </div>
            </div>

            {/* Biometrics */}
            <div className="pt-2 border-t border-slate-100">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-3">
                Biometrics & Yield
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <div>
                  <label className="block text-[11px] text-slate-600 mb-1">
                    Trunk Girth (cm)
                  </label>
                  <input
                    type="number"
                    value={formData.trunkSize || ''}
                    onChange={(e) => setFormData({ ...formData, trunkSize: parseFloat(e.target.value) || 0 })}
                    className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg font-mono tabular-nums"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-600 mb-1">
                    Canopy Spread
                  </label>
                  <input
                    type="text"
                    value={formData.canopySize || ''}
                    onChange={(e) => setFormData({ ...formData, canopySize: e.target.value })}
                    className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-600 mb-1">
                    Flower Clusters
                  </label>
                  <input
                    type="number"
                    value={formData.floweringClusters || ''}
                    onChange={(e) => setFormData({ ...formData, floweringClusters: parseInt(e.target.value, 10) || 0 })}
                    className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg font-mono tabular-nums"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-emerald-800 mb-1">
                    Est. Fruits
                  </label>
                  <input
                    type="number"
                    value={formData.estimatedFruitCount || ''}
                    onChange={(e) => setFormData({ ...formData, estimatedFruitCount: parseInt(e.target.value, 10) || 0 })}
                    className="w-full text-xs p-2 bg-emerald-50/50 border border-emerald-300 rounded-lg font-mono tabular-nums font-bold text-emerald-800 focus:bg-white"
                  />
                </div>
              </div>
            </div>

            {/* General Notes */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Admin Notes
              </label>
              <textarea
                rows={2}
                value={formData.notes || ''}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="Grafting details, fertilization history, irrigation..."
                className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>
          </form>
        </div>

        {/* Right: Inspection Timeline with Photos (5 cols) */}
        <div className="lg:col-span-5 bg-white rounded-xl border border-slate-200 shadow-xs flex flex-col overflow-hidden">
          <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-emerald-600" />
              Inspection Log ({treeReports.length})
            </h2>
            <span className="text-[11px] text-slate-400">WhatsApp Submissions</span>
          </div>

          <div className="p-4 overflow-y-auto max-h-[640px]">
            {treeReports.length === 0 ? (
              <div className="py-12 text-center text-slate-400 space-y-1">
                <p className="text-xs font-medium">No inspection reports for Tree {treeId}.</p>
                <p className="text-[11px] text-slate-400">Reports submitted via WhatsApp bot will appear here.</p>
              </div>
            ) : (
              <div className="relative pl-7 space-y-3.5">
                {/* Continuous neat timeline spine */}
                <div
                  aria-hidden="true"
                  className="absolute left-[11px] top-3.5 bottom-3.5 w-0.5 bg-slate-200"
                />

                {treeReports.map((report) => {
                  const photos = report.photos || [];

                  return (
                    <div key={report.id} className="relative">
                      {/* Timeline node perfectly centered on the line */}
                      <div
                        aria-hidden="true"
                        className="absolute -left-7 top-3.5 w-6 flex items-center justify-center pointer-events-none"
                      >
                        <div className="w-2.5 h-2.5 rounded-full bg-white ring-2 ring-emerald-500 shadow-2xs" />
                      </div>

                      <div className="p-3.5 rounded-xl border border-slate-200 bg-white hover:border-slate-300 shadow-2xs space-y-2.5 transition-all">
                        {/* Header & Subheading */}
                        <div className="space-y-1">
                          {/* Header row: Tree A12 · MK & Condition */}
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-xs font-bold font-mono text-slate-900">
                              Tree {treeId} · {tree?.variant || formData.variant || 'MK'}
                            </span>

                            {report.conditionChanged && report.conditionBefore && report.conditionAfter ? (
                              <div className="flex items-center gap-1.5 text-xs">
                                <span className="text-slate-500 font-medium lowercase">{report.conditionBefore}</span>
                                <span className="text-slate-400">→</span>
                                <ConditionBadge condition={report.conditionAfter} size="sm" />
                              </div>
                            ) : (
                              report.conditionAfter && (
                                <ConditionBadge condition={report.conditionAfter} size="sm" />
                              )
                            )}
                          </div>

                          {/* Subheading row: Block name horizontally aligned with report date */}
                          <div className="flex items-center justify-between text-[11px] text-slate-500">
                            <span>Block {report.block || formData.block || '—'}</span>
                            <span className="text-slate-400 font-normal">
                              {formatDateTime(report.createdAt)}
                            </span>
                          </div>
                        </div>

                        {/* Worker identifier */}
                        {report.workerPhone && (
                          <div className="flex items-center gap-1.5 text-[11px] text-slate-500 font-mono">
                            <User className="w-3.5 h-3.5 text-slate-400" />
                            <span>{report.workerPhone}</span>
                          </div>
                        )}

                        {/* Description */}
                        {report.description && (
                          <p className="text-xs text-slate-700 leading-relaxed bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                            {report.description}
                          </p>
                        )}

                        {/* Photo thumbnails */}
                        {photos.length > 0 && (
                          <div className="pt-0.5">
                            <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider block mb-1.5">
                              Photos ({photos.length})
                            </span>
                            <div className="grid grid-cols-3 gap-2">
                              {photos.map((photo, pIdx) => (
                                <ThumbnailItem
                                  key={pIdx}
                                  photo={photo}
                                  idx={pIdx}
                                  reportDate={report.createdAt}
                                  treeId={treeId}
                                  onOpen={(url, caption) => setActivePhoto({ url, caption })}
                                />
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Lightbox for full photo viewing */}
      <PhotoLightbox
        photoUrl={activePhoto?.url || null}
        caption={activePhoto?.caption}
        onClose={() => setActivePhoto(null)}
      />
    </div>
  );
};
