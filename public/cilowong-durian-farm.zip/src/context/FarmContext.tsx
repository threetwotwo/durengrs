import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { collection, onSnapshot } from 'firebase/firestore';
import { DurianTree, DurianVariant, TreeReport } from '../types';
import {
  db,
  activeProjectId,
  saveTreeToFirestore,
  saveVariantToFirestore,
  normalizePhotos,
  handleFirestoreError,
  OperationType,
} from '../lib/firebase';

interface FarmContextType {
  trees: DurianTree[];
  variants: DurianVariant[];
  reports: TreeReport[];
  loading: boolean;
  currentProjectId: string;
  error: string | null;
  selectedTreeId: string | null;
  setSelectedTreeId: (id: string | null) => void;
  activeTab: 'dashboard' | 'trees' | 'variants' | 'reports';
  setActiveTab: (tab: 'dashboard' | 'trees' | 'variants' | 'reports') => void;
  updateTree: (tree: Partial<DurianTree> & { id: string }) => Promise<void>;
  saveVariant: (variant: DurianVariant) => Promise<void>;
  filterBlock: string;
  setFilterBlock: (block: string) => void;
  filterCondition: string;
  setFilterCondition: (cond: string) => void;
  totalFruits: number;
}

const FarmContext = createContext<FarmContextType | null>(null);

export const FarmProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [trees, setTrees] = useState<DurianTree[]>([]);
  const [variants, setVariants] = useState<DurianVariant[]>([]);
  const [reports, setReports] = useState<TreeReport[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedTreeId, setSelectedTreeId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'trees' | 'variants' | 'reports'>('dashboard');
  const [filterBlock, setFilterBlock] = useState<string>('all');
  const [filterCondition, setFilterCondition] = useState<string>('all');

  const loadData = useCallback(() => {
    setLoading(true);
    setError(null);

    let unsubscribeTrees = () => {};
    let unsubscribeVariants = () => {};
    let unsubscribeReports = () => {};

    try {
      // 1. Subscribe to 'trees' in default Firestore
      const treesCol = collection(db, 'trees');
      unsubscribeTrees = onSnapshot(
        treesCol,
        (snapshot) => {
          const list: DurianTree[] = snapshot.docs.map((docSnap) => {
            const data = docSnap.data();
            return {
              id: docSnap.id,
              variant: data.variant || '',
              block: data.block || '',
              condition: data.condition || 'healthy',
              conditionNotes: data.conditionNotes || '',
              canopySize: data.canopySize || '',
              trunkSize: Number(data.trunkSize) || 0,
              floweringBranches: Number(data.floweringBranches) || 0,
              floweringClusters: Number(data.floweringClusters) || 0,
              estimatedFruitCount: Number(data.estimatedFruitCount) || 0,
              notes: data.notes || '',
              supplier: data.supplier || '',
              datePlanted: data.datePlanted,
              treeNumber: data.treeNumber,
              active: data.active,
              dateCreated: data.dateCreated,
              dateUpdated: data.dateUpdated,
              conditionUpdatedAt: data.conditionUpdatedAt,
              lastReportAt: data.lastReportAt,
              lastReportId: data.lastReportId,
            };
          });
          // Sort trees naturally by block then ID
          list.sort((a, b) => a.id.localeCompare(b.id, undefined, { numeric: true, sensitivity: 'base' }));
          setTrees(list);
          setLoading(false);
        },
        (err) => {
          console.error('Firestore trees error:', err);
          setError(`Firestore error reading 'trees': ${err.message}`);
          setLoading(false);
          try {
            handleFirestoreError(err, OperationType.LIST, 'trees');
          } catch {}
        }
      );

      // 2. Subscribe to 'variants' in default Firestore
      const variantsCol = collection(db, 'variants');
      unsubscribeVariants = onSnapshot(
        variantsCol,
        (snapshot) => {
          const list: DurianVariant[] = snapshot.docs.map((docSnap) => {
            const data = docSnap.data();
            const name = data.description || data.name || docSnap.id;
            return {
              code: docSnap.id,
              name: name,
              description: data.description || '',
              origin: data.origin || '',
              characteristics: data.characteristics || '',
              ripeningDays: data.ripeningDays,
            };
          });
          list.sort((a, b) => a.name.localeCompare(b.name));
          setVariants(list);
        },
        (err) => {
          console.error('Firestore variants error:', err);
          try {
            handleFirestoreError(err, OperationType.LIST, 'variants');
          } catch {}
        }
      );

      // 3. Subscribe to 'reports' in default Firestore
      const reportsCol = collection(db, 'reports');
      unsubscribeReports = onSnapshot(
        reportsCol,
        (snapshot) => {
          const list: TreeReport[] = snapshot.docs.map((docSnap) => {
            const data = docSnap.data();
            const rawPhotos =
              data.photos ||
              data.photoUrls ||
              data.images ||
              data.image ||
              data.photo ||
              data.media ||
              [];

            return {
              id: docSnap.id,
              treeId: data.treeId || '',
              block: data.block || '',
              workerPhone: data.workerPhone || '',
              description: data.description || '',
              photos: normalizePhotos(rawPhotos),
              conditionBefore: data.conditionBefore,
              conditionAfter: data.conditionAfter,
              conditionChanged: Boolean(data.conditionChanged),
              createdAt: data.createdAt,
            };
          });

          // Sort reports newest first
          list.sort((a, b) => {
            const timeA = normalizeTimestamp(a.createdAt);
            const timeB = normalizeTimestamp(b.createdAt);
            return timeB - timeA;
          });
          setReports(list);
        },
        (err) => {
          console.error('Firestore reports error:', err);
          try {
            handleFirestoreError(err, OperationType.LIST, 'reports');
          } catch {}
        }
      );
    } catch (e: any) {
      console.error('Failed to attach listeners:', e);
      setError(`Failed to attach Firestore listeners: ${e.message}`);
      setLoading(false);
    }

    return () => {
      unsubscribeTrees();
      unsubscribeVariants();
      unsubscribeReports();
    };
  }, []);

  useEffect(() => {
    const unsub = loadData();
    return () => unsub?.();
  }, [loadData]);

  const updateTree = async (updatedFields: Partial<DurianTree> & { id: string }) => {
    await saveTreeToFirestore(updatedFields);
    setTrees((prev) =>
      prev.map((t) => (t.id === updatedFields.id ? { ...t, ...updatedFields } : t))
    );
  };

  const saveVariant = async (variant: DurianVariant) => {
    await saveVariantToFirestore(variant);
    setVariants((prev) => {
      const idx = prev.findIndex((v) => v.code === variant.code);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = variant;
        return next;
      }
      return [variant, ...prev];
    });
  };

  const totalFruits = trees.reduce((acc, t) => acc + (t.estimatedFruitCount || 0), 0);

  return (
    <FarmContext.Provider
      value={{
        trees,
        variants,
        reports,
        loading,
        currentProjectId: activeProjectId,
        error,
        selectedTreeId,
        setSelectedTreeId,
        activeTab,
        setActiveTab,
        updateTree,
        saveVariant,
        filterBlock,
        setFilterBlock,
        filterCondition,
        setFilterCondition,
        totalFruits,
      }}
    >
      {children}
    </FarmContext.Provider>
  );
};

export function useFarm() {
  const ctx = useContext(FarmContext);
  if (!ctx) {
    throw new Error('useFarm must be used within a FarmProvider');
  }
  return ctx;
}

export function normalizeTimestamp(val: any): number {
  if (!val) return 0;
  if (typeof val === 'number') return val;
  if (typeof val.toMillis === 'function') return val.toMillis();
  if (val.seconds) return val.seconds * 1000;
  const d = new Date(val);
  return isNaN(d.getTime()) ? 0 : d.getTime();
}

export function formatDateTime(val: any): string {
  const ts = normalizeTimestamp(val);
  if (!ts) return '—';
  const d = new Date(ts);
  return d.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function formatDate(val: any): string {
  const ts = normalizeTimestamp(val);
  if (!ts) return '—';
  const d = new Date(ts);
  return d.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}
